const  a = "sakshi";
const b = "aaaa";
const c = "bbb";
const d = "bbee";
export default b;
export {a};
export {c};
export {d};