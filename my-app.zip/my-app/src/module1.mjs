import ui , {a,c,d} from './module2.mjs';
console.log(ui);
console.log(a);
console.log(c);
console.log(d);